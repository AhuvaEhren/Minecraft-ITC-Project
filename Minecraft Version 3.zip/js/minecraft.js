var minecraft_game = {};
minecraft_game.rows = 16;
minecraft_game.columns = 26;
minecraft_game.board = document.getElementById("board");
minecraft_game.startPage = document.getElementById("container1");
minecraft_game.startButton = document.getElementById("start-btn");
minecraft_game.tutorialButton = document.getElementById("tutorial-btn");
minecraft_game.tutorialModal = document.getElementById("tutorialModal");
minecraft_game.closeModalButton = document.getElementById("close");
minecraft_game.gamePage = document.getElementById("container2");

//start button
minecraft_game.startButton.addEventListener("click", minecraft_game.startGame = function(){
    minecraft_game.startPage.classList.add("display-none");
    minecraft_game.gamePage.classList.remove("display-none");
});

//tutorial button
minecraft_game.tutorialButton.addEventListener("click", minecraft_game.showTutorial = function(){
    minecraft_game.tutorialModal.classList.remove("display-none");
});

// When the user clicks on the X, close the modal
minecraft_game.closeModalButton.onclick = function() {
    minecraft_game.tutorialModal.classList.add("display-none");
  }

  // When the user clicks anywhere outside of the modal, close the modal
window.onclick = function(event) {
    if (event.target == minecraft_game.tutorialModal) {
        minecraft_game.tutorialModal.classList.add("display-none");
    }
  }

//var myBoard = [];

//board
minecraft_game.createBoard = function () {
    for (let j = 0; j < minecraft_game.rows; j++) {
        //var arrayTwo = [];
        //let rowDiv = document.createElement("div");
        //rowDiv.classList.add("row" + j);
        for (let i = 0; i < minecraft_game.columns; i++) {
            //arrayTwo.push(i);
            let colDiv = document.createElement("div");
            colDiv.classList.add("sky", "cell");
            colDiv.classList.add("col-" + i);
            colDiv.classList.add("row-" + j);
            minecraft_game.board.append(colDiv);
        }
        //myBoard.push(arrayTwo);
        //rowDiv.classList.add("row" + j);
    }
}

minecraft_game.createBoard();

minecraft_game.cloud = document.querySelectorAll(".row-0.col-3,.row-1.col-2,.row-1.col-3,.row-1.col-4,.row-2.col-1,.row-2.col-2,.row-2.col-3,.row-2.col-4,.row-2.col-5, .row-1.col-16, .row-1.col-17, .row-2.col-15, .row-2.col-16 ");
minecraft_game.cloud.forEach(item => {
    item.classList.add('cloud');
})

minecraft_game.leaves = document.querySelectorAll(".row-3.col-9,.row-3.col-10,.row-4.col-8,.row-4.col-9,.row-4.col-10,.row-4.col-11,.row-4.col-20,.row-5.col-8,.row-5.col-11,.row-5.col-19,.row-5.col-20,.row-5.col-21,.row-6.col-19,.row-6.col-21");
minecraft_game.leaves.forEach(item => {
    item.classList.add('leaves');
})

minecraft_game.wood = document.querySelectorAll(".row-5.col-9,.row-8.col-10,.row-7.col-10,.row-7.col-11,.row-6.col-10,.row-5.col-10,.row-8.col-20,.row-7.col-20,.row-6.col-20");
minecraft_game.wood.forEach(item => {
    item.classList.add('wood');
})

minecraft_game.stone = document.querySelectorAll(".row-7.col-5,.row-8.col-4,.row-8.col-5,.row-8.col-6,.row-8.col-16,.row-8.col-17");
minecraft_game.stone.forEach(item => {
    item.classList.add('stone');
})

minecraft_game.grass = document.querySelectorAll(".row-9");
minecraft_game.grass.forEach(item => {
    item.classList.add('grass');
})

minecraft_game.dirt = document.querySelectorAll(".row-10,.row-11,.row-12,.row-13,.row-14,.row-15");
minecraft_game.dirt.forEach(item => {
    item.classList.add('dirt');
})

